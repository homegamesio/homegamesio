// Adapted from Homegames' sound-test: scene nodes, click input and audio all
// use the existing engine. Media is now part of this project directory.
const { Asset, Game, GameNode, Shapes, ShapeUtils } = require('squish-142');
const { message } = require('./lib/message');

class PortableSound extends Game {
    static metadata() {
        return {
            name: 'Pocket Chime', squishVersion: '142',
            aspectRatio: { x: 16, y: 9 }, tickRate: 30,
            services: ['multiplayer'], maxPlayers: 4,
            assets: {
                tile: new Asset({ path: './assets/tile.png', type: 'image' }),
                chime: new Asset({ path: './assets/chime.wav', type: 'audio' })
            }
        };
    }

    constructor() {
        super();
        this.clicks = 0;
        this.base = new GameNode.Shape({ shapeType: Shapes.POLYGON,
            coordinates2d: ShapeUtils.rectangle(0, 0, 100, 100), fill: [16, 24, 32, 255],
            onClick: () => this.chime() });
        this.title = new GameNode.Text({ textInfo: {
            text: 'POCKET CHIME', x: 50, y: 15, size: 4, color: [241, 248, 252, 255], align: 'center', font: 'default'
        } });
        this.tile = new GameNode.Asset({ coordinates2d: ShapeUtils.rectangle(40, 28, 20, 36),
            assetInfo: { tile: { pos: { x: 40, y: 28 }, size: { x: 20, y: 36 } } },
            onClick: () => this.chime() });
        this.label = new GameNode.Text({ textInfo: {
            text: message(0), x: 50, y: 77, size: 2.5, color: [148, 203, 221, 255], align: 'center', font: 'default'
        } });
        this.base.addChild(this.title);
        this.base.addChild(this.tile);
        this.base.addChild(this.label);
    }

    chime() {
        this.clicks++;
        this.label.node.text.text = message(this.clicks);
        this.tile.clearChildren();
        this.tile.addChild(new GameNode.Asset({
            coordinates2d: ShapeUtils.rectangle(0, 0, 0, 0),
            assetInfo: { chime: { pos: { x: 0, y: 0 }, size: { x: 0, y: 0 }, startTime: 0 } }
        }));
        this.base.node.onStateChange();
    }

    getLayers() { return [{ root: this.base }]; }
}

module.exports = PortableSound;
